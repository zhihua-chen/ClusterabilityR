# Clusterability R Package
The **clusterability** package tests for cluster tendancy of a dataset. Results of these tests can inform whether clustering algorithms are appropriate for the data.

## Installation
You can install the released version of clusterability from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("clusterability")
```

## Example

This demonstrates the use of the `clusterabilitytest` function to determine if the four numeric variables of the [*iris*](https://stat.ethz.ch/R-manual/R-devel/library/datasets/html/iris.html) dataset have a natural cluster tendency.

#### Input
``` r
library(clusterability)
data(iris)
iris_numeric <- iris[,c(1:4)]
iris_result <- clusterabilitytest(iris_numeric, "dip")
print(iris_result)
```

#### Output
```
----------------------
Clusterability Test
----------------------

Data set name: iris_numeric
Your data set has 150 observation(s) and 4 variable(s).
There were no missing values. Your data set is complete.

Data Reduced Using: PCA

-----------------------------------------
Results: Dip Test of Unimodality
-----------------------------------------

Null Hypothesis: number of modes = 1
Alternative Hypothesis: number of modes > 1
p-value: 0 
Dip statistic: 0.107841006841301 

---------------------
Test Options Used
---------------------

Default values for the optional parameters were used. To learn more about customizing the behavior of the clusterabilitytest, please see the R documentation.

```

## Main Parameters



## Supplemental Files

#### README.md

#### NEWS.md
