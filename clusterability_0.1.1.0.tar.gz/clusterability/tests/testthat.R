library(testthat)
library(clusterability)

test_check("clusterability")
